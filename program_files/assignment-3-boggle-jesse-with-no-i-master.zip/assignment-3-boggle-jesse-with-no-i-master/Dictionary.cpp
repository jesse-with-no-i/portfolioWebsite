#include "Dictionary.h"

// Your code here


Dictionary::Dictionary() {
    numWords = 0;
    root = new Node;
}

Dictionary::Dictionary(string filename) {
    numWords = 0;
    root = new Node;

    LoadDictionaryFile(filename);
}

Dictionary::~Dictionary() {
    destroyHelper(root);
}

Dictionary::Dictionary(const Dictionary &otherDict) {   // copy constructor

    numWords = 0;
    root = new Node;


    copyOther(otherDict);
}

void Dictionary::copyOther(const Dictionary &otherDict) {
    // clear this dictionary
    MakeEmpty();
    numWords = otherDict.numWords;

    copyHelper(root, otherDict.root);
}

void Dictionary::copyHelper(Dictionary::Node *&thisTree, Dictionary::Node *otherTree) {

    if (otherTree == nullptr) {
        thisTree = nullptr;
        return;
    }

    thisTree = new Node;
    // check if the current path is a word
    thisTree->isWord = otherTree->isWord;


    for (int i = 0; i < NUM_CHARS; i++) {
        // check if the path we are trying to copy exists
        if (otherTree->branches[i] != nullptr) {
            copyHelper(thisTree->branches[i], otherTree->branches[i]);
        }
        else {
            thisTree->branches[i] = nullptr;
        }
    }
}

Dictionary &Dictionary::operator=(const Dictionary &otherDict) {
    // skip if trying to set self equal to self

    if (otherDict.root != root) {
        copyOther(otherDict);
    }
    return *this;

}

void Dictionary::LoadDictionaryFile(string filename) {
    // open the file
    ifstream infile;
    infile.open(filename);

    string currWord;
    // flag variable for while loop
    bool lastLineRead = false;

    infile >> currWord; // load first word into a variable
    while (!lastLineRead) {
        AddWord(currWord);

        // if the end of the file is reached, need to read last word still
        if (infile.peek() == EOF) {
            lastLineRead = true;
        }

        infile >> currWord;     // load next word into currWord
    }

    // close the file
    infile.close();
}

void Dictionary::SaveDictionaryFile(string filename) {
    // open the file
    ofstream outfile;
    outfile.open(filename);

    SaveDictionaryHelper(root, "", outfile);

    outfile.close();
}

void Dictionary::SaveDictionaryHelper(Dictionary::Node *curr, string currPrefix, ofstream &outFile) {

    string temp;

    if (curr->isWord) {
        outFile << currPrefix;
        outFile << endl;
    }

    for (int i = 0; i < NUM_CHARS; i++) {
        if (curr->branches[i] != nullptr) {
            // save current "version" of the string so we don't lose it
            // when we move to the next branch
            temp = currPrefix;
            currPrefix += (char) (i + (int)'a');
            SaveDictionaryHelper(curr->branches[i], currPrefix, outFile);
            currPrefix = temp;
        }
    }

}

void Dictionary::AddWord(string word) {
    Node* curr = root;
    int index;

    for (int i=0; i < word.size(); i++) {
        index = (int) word[i] - (int) 'a';

        if (index < 0 || index > (NUM_CHARS - 1)) {    // check if the character is valid
            throw DictionaryError("Invalid character");
        }

        if (curr->branches[index] == nullptr) { // if no branch exists for this character
            // make a new node at the index of branches that matches the character
            curr->branches[index] = new Node;
        }

        curr = curr->branches[index];
    }
    // check if the word is already in the dictionary
    if (!curr->isWord) {
        numWords++;
    }

    // make the word valid by setting isWord to true
    curr->isWord = true;
}

void Dictionary::MakeEmpty() {
    destroyHelper(root);
    // create new root and reset numWords
    numWords = 0;
    root = new Node;
}

void Dictionary::destroyHelper(Dictionary::Node *thisTree) {
    // if the tree is null, we can return
    if (thisTree == nullptr) {
        return;
    }

    // destroy all the branches, then destroy self
    for (int i = 0; i < NUM_CHARS; i++) {
        destroyHelper(thisTree->branches[i]);
    }

    delete thisTree;
}

bool Dictionary::IsWord(string word) {
    // start at root
    Node* curr = root;
    int index;

    // for each character in the string...
    for (int i=0; i < word.size(); i++) {
        // get the numeric index for the character
        index = (int)word[i] - (int)'a';

        if (index < 0 || index > (NUM_CHARS - 1)) {    // check if the character is valid
            throw DictionaryError("Invalid character");
        }

        // move curr to the branch for the character
        curr = curr->branches[index];

        if (curr == nullptr) {
            return false;
        }
    }
    return curr->isWord;
}

bool Dictionary::IsPrefix(string word) {
    // start at root
    Node* curr = root;
    int index;

    // for each character in the string...
    for (int i=0; i < word.size(); i++) {
        // get the numeric index for the character
        index = (int)word[i] - (int)'a';

        if (index < 0 || index > (NUM_CHARS - 1)) {    // check if the character is valid
            throw DictionaryError("Invalid character");
        }

        // move curr to the branch for the character
        curr = curr->branches[index];

        if (curr == nullptr) {
            return false;
        }
    }
    return true;
}

int Dictionary::WordCount() {
    return numWords;
}


