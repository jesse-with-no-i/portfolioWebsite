
#include "Dictionary.h"
#include "Boggle.h"

// Your code here


// This function is done.
Dictionary Boggle::GetDictionary() {
    return dict;
}

// This function is done.
Dictionary Boggle::WordsFound() {
    return wordsFound;
}

Boggle::Boggle() {
    // initialize dictionary with dictionary.txt
    dict.LoadDictionaryFile("dictionary.txt");

    // initialize board to empty strings and visited to all 0s
    for (int row = 0; row < BOARD_SIZE; row++) {
        for (int col = 0; col < BOARD_SIZE; col++) {
            board[row][col] = "";
            visited[row][col] = 0;
        }
    }
}

Boggle::Boggle(string filename) {
    dict.LoadDictionaryFile(filename);

    // initialize board to empty strings and visited to all 0s
    for (int row = 0; row < BOARD_SIZE; row++) {
        for (int col = 0; col < BOARD_SIZE; col++) {
            board[row][col] = "";
            visited[row][col] = 0;
        }
    }
}

void Boggle::SetBoard(string board[BOARD_SIZE][BOARD_SIZE]) {
    // copy each entry of board to this->board
    for (int row = 0; row < BOARD_SIZE; row++) {
        for (int col = 0; col < BOARD_SIZE; col++) {
            this->board[row][col] = board[row][col];
            this->visited[row][col] = 0;
        }
    }
}

void Boggle::SolveBoard(bool printBoard, ostream &output) {
    // reset the wordsFound dictionary
    wordsFound.MakeEmpty();

    // call the helper function from each position on the board
    for (int row = 0; row < BOARD_SIZE; row++) {
        for (int col = 0; col < BOARD_SIZE; col++) {
            SolveBoardHelper(row, col, 1, "", printBoard, output);
        }
    }
}

void Boggle::SolveBoardHelper(int row, int col, int step, string currPath, bool printBoard,
                              ostream& output) {

    // if the current string is a word in the dictionary, save it to wordsFound
    if (dict.IsWord(currPath)) {

        // don't print if the word has already been added
        if(!wordsFound.IsWord(currPath)) {

            // print out the word depending on the value of printBoard
            if (printBoard) {
                output << "Word: " << currPath << endl;
                output << "Number of Words: " << wordsFound.WordCount() + 1 << endl;
                PrintBoard(output);
            }
            else {
                output << wordsFound.WordCount() + 1 << "\t" << currPath << endl;
            }
        }
        // word added after to allow word to be printed once
        wordsFound.AddWord(currPath);
    }

    // base cases
    // out of bounds: just return
    if (row < 0 || row >= BOARD_SIZE || col < 0 || col >= BOARD_SIZE) {
        return;
    }
    // position has been used
    if (visited[row][col] > 0) {
        return;
    }
    // currPath is an invalid prefix
    if (!dict.IsPrefix(currPath)) {
        return;
    }

    visited[row][col] = step;

    // north
    SolveBoardHelper(row-1, col, step+1, currPath+board[row][col], printBoard, output);
    // northeast
    SolveBoardHelper(row-1, col+1, step+1, currPath+board[row][col], printBoard, output);
    // east
    SolveBoardHelper(row, col+1, step+1, currPath+board[row][col], printBoard, output);
    // southeast
    SolveBoardHelper(row+1, col+1, step+1, currPath+board[row][col], printBoard, output);
    // south
    SolveBoardHelper(row+1, col, step+1, currPath+board[row][col], printBoard, output);
    // southwest
    SolveBoardHelper(row+1, col-1, step+1, currPath+board[row][col], printBoard, output);
    // west
    SolveBoardHelper(row, col-1, step+1, currPath+board[row][col], printBoard, output);
    // northwest
    SolveBoardHelper(row-1, col-1, step+1, currPath+board[row][col], printBoard, output);

    // if all these recursive calls pass, revert visited matrix to previous state
    visited[row][col] = 0;
}

void Boggle::SaveSolve(string filename) {
    wordsFound.SaveDictionaryFile(filename);
}

void Boggle::PrintBoard(ostream &output) {

    for (int r = 0; r < BOARD_SIZE; r++) {

        // printing the board
        for (int c = 0; c < BOARD_SIZE; c++) {
            // only print quotes if visited of the same location > 0
            if (visited[r][c] > 0) {
                output << " '" << board[r][c] << "' ";
            }
            else {
                output << "  " << board [r][c] << "  ";
            }
        }
        // printing out the space in between board and visited
        output << "\t";

        // printing visited
        for (int c = 0; c < BOARD_SIZE; c++) {
            output << "  " << visited[r][c] << "  ";
        }
        output << endl;
    }
    // print out newline in between solves
    output << endl;
}

