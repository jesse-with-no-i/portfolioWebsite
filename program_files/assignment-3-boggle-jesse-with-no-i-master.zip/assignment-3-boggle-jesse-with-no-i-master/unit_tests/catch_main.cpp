#define CATCH_CONFIG_MAIN
#include "catch.hpp"

// Catch requires CATCH_CONFIG_MAIN to be only defined once across all files.
// We use this file to declare it.  No tests are actually in this file.