## You will find grading comments here 

| Deliverable        | Points | Points Earned | Comments
| ------------------ | ------ | ------------- | ------------------------
| Tests              |  65    |      ![Points badge](../../blob/badges/.github/badges/points.svg)       |
| Questions          |  15    |       15      |
| Commits            |  10    |       10      |
| Commenting         |  10    |       10      |



## Comments on Answer to Questions

| Questions | Points | Points Earned | Comments
| --------- | ------ | ------------- | -----------------------
|     1     |   3    |      3        | 
|     2     |   3    |      3        |
|     3     |   3    |      3        |
|     4     |   3    |      3        |
|     5     |   3    |      3        |


## Late Days

| Late Days Issue      | Points & Days    | Points Earned or Deducted 
| -------------------- | ---------------- | ------------- 
| Bonus Points         |        6.5       |      +6.5
| Late Days Used       |        0         |      -0


### *AG - Auto Graded


