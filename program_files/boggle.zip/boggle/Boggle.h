#ifndef BOGGLE_BOGGLE_H
#define BOGGLE_BOGGLE_H

#include <string>
#include "Dictionary.h"

using namespace std;

const int BOARD_SIZE = 4;

class BoardNotInitialized {};

class Boggle {
public:
    Boggle();  // load "dictionary.txt" into dict
    /*
     * pre:
     * - none
     *
     * post:
     * - dict is initialized with words from dictionary.txt
     * - each entry of board is initialized to ""
     * - each entry of visited is initialized to false
     */

    explicit Boggle(string filename);  // load filename into dict
    /*
     * pre:
     * - a filename is given
     *
     * post:
     * - dict is initialized with words from file given
     * - each entry of board is initialized to ""
     * - each entry of visited is initialized to false
     */

    void SetBoard(string board[BOARD_SIZE][BOARD_SIZE]);
    /*
     * pre:
     * - a board is provided
     *
     * post:
     * - each entry of the provided board is copied to this board
     */

    void SolveBoard(bool printBoard, ostream& output);
    /*
     * pre:
     * - boolean value is provided
     * - an output source is provided
     * - board is initialized
     *
     * post:
     * - wordsFound contains the words found on the current board
     * - values output to output source provided
     */

    void SaveSolve(string filename);   // Saves all the words from the last solve.
    /*
     * pre:
     * - a filename is given
     *
     * post:
     * - wordsFound is saved to the file given
     */

    Dictionary GetDictionary();
    /*
     * pre:
     * - none
     *
     * post:
     * - dict is returned
     */

    Dictionary WordsFound();
    /*
     * pre:
     * - none
     *
     * post:
     * - wordsFound is returned
     */

private:
    Dictionary dict;
    Dictionary wordsFound;
    string board[BOARD_SIZE][BOARD_SIZE];
    int visited[BOARD_SIZE][BOARD_SIZE];

    void PrintBoard(ostream& output);
    void SolveBoardHelper(int row, int col, int step, string currPath, bool printBoard, ostream& output);
};

#endif //BOGGLE_BOGGLE_H
