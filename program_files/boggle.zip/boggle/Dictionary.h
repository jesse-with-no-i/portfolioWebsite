#ifndef BOGGLE_DICTIONARY_H
#define BOGGLE_DICTIONARY_H

#include <iostream>
#include <fstream>
#include <string>
using namespace std;


const int NUM_CHARS = 26;

class DictionaryError{
public:
    explicit DictionaryError(string msg) {
        this->msg = msg;
    }
    string Msg(){
        return msg;  // returns king of flavor
    }
private:
    string msg;
};

class Dictionary
{

public:
    Dictionary();
    /*
     * (Constructor)
     *
     * pre:
     * - none
     *
     * post:
     * - a new Dictionary object is created
     * - numWords = 0
     * - root points to a new Node
     * - all elements in root's pointer array are nullptr
     */

    ~Dictionary();  // I will not require this
    /*
     * pre:
     * - none
     *
     * post:
     * - all nodes in the dictionary are destroyed and the dictionary is deleted
     */

    Dictionary(const Dictionary& otherDict);    // copy constructor
    /*
     * pre:
     * - a dictionary object is provided
     *
     * post:
     * - the contents of otherDict are copied to this dictionary
     */

    explicit Dictionary(string filename);       // The keyword explicit is used to tell the compiler
                                                // that this is not a conversion constructor.
    /*
     * pre:
     * - a filename is provided
     *
     * post:
     * - a new dictionary is created
     * - the words in the file are added to the dictionary
     */

    Dictionary& operator=(const Dictionary& otherDict);
    /*
     * pre:
     * - (operator overload)
     * - a dictionary object is provided
     *
     * post:
     * - the contents of otherDict are copied to this dictionary
     */

    void LoadDictionaryFile(string filename);
    /*
     * pre:
     * - a filename is provided
     *
     * post:
     * - the words in the file are added to this dictionary
     */

    void SaveDictionaryFile(string filename);
    /*
     * pre:
     * - a filename is provided
     *
     * post:
     * - all words in the dictionary are written to the file
     */

    void AddWord(string word);
    /*
     * pre:
     * - a string of lowercase alphabetic characters is provided
     *
     * post:
     * - the word is added to the dictionary (if it's not already there)
     * - if any of the characters are not between a - z, error thrown
     */

    void MakeEmpty();
    /*
     * pre:
     * - none
     *
     * post:
     * - all nodes in the dictionary are destroyed
     */

    bool IsWord(string word);
    /*
     * pre:
     * - a string of lowercase alphabetic characters is provided
     *
     * post:
     * - returns true if the string is a word
     * - if any of the characters are not between a - z, error thrown
     */

    bool IsPrefix(string word);
    /*
     * pre:
     * - a string of lowercase alphabetic characters is provided
     *
     * post:
     * - returns true if a path for that string exists in the dictionary
     * - if any of the characters are not between a - z, error thrown
     */

    int WordCount();
    /*
     * pre:
     * - none
     *
     * post:
     * - Returns total number of words in dictionary
     */

private:

    class Node {
    public:
        // Your node structure here.
        // You can also use a struct if you like.

        // It is strongly recommended you create a constructor
        // to set default values

        // default constructor for Node
        Node() {
            // set each position of the branch array to null
            for (int i=0; i<NUM_CHARS; i++) {
                this->branches[i] = nullptr;
            }
        };

        Node* branches[NUM_CHARS];     // finding the index of a character: (int)'e' - (int)'a'
        bool isWord = false;           // ^ reverse: (char) (5 + (int)'a')
    };

    Node* root;
    int numWords;

    // This function is used by the
    // copy constructor and the assignment operator.
    void copyOther(const Dictionary& otherDict);

    // Any private methods you need/want
    // You may change these helpers if you want, but you don't need to.
    void destroyHelper(Node* thisTree);
    void copyHelper(Node*& thisTree, Node* otherTree);
    void SaveDictionaryHelper(Node* curr, string currPrefix, ofstream& outFile);
};

#endif //BOGGLE_DICTIONARY_H
